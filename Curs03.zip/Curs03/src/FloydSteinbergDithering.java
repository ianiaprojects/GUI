import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class FloydSteinbergDithering extends JPanel {

	private BufferedImage initialImage, ditheredImage;
	private int width, height;
	private int errorRed, errorGreen, errorBlue;
	private Color[] palleteColors = new Color[] {
			//new Color(  0,   0,   0),				
			new Color(255,   0,   0),		
			new Color(  0, 255,   0),		
			new Color(  0,   0, 255),		
			new Color(255, 255,   0),				
			new Color(255, 0  , 255),
			new Color(  0, 255, 255),
			new Color(255, 255, 255)
	};
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String filename = "ciri.jpg";
		FloydSteinbergDithering mainFrame = new FloydSteinbergDithering(filename);
		mainFrame.displayResult();
	}

	public void displayResult() {
		JFrame frame = new JFrame();

		ImageIcon icon1 = new ImageIcon(initialImage);
		ImageIcon icon2 = new ImageIcon(ditheredImage);

		JLabel label1 = new JLabel(icon1); 
		JLabel label2 = new JLabel(icon2); 

		add(label1);
		add(label2);

		frame.add(this);
		frame.pack();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	public FloydSteinbergDithering(String filename) throws IOException {

		this.initialImage = ImageIO.read(new File(filename));
		this.ditheredImage = ImageIO.read(new File(filename));

		width = initialImage.getWidth();
		height = initialImage.getHeight();

		algorithm();
	}

	private void algorithm() {
		Color pixel[][] = new Color[this.width][this.height];
		for(int x = 0; x < this.width; x++)
			for(int y = 0; y < this.height; y++)
				pixel[x][y] = new Color(this.initialImage.getRGB(x, y));
		
		for(int y = 0; y < this.height-1; y++) {
			for (int x = 1; x < this.width-1; x++) {			
				Color newPixel = findClosestPalleteColor(pixel[x][y]);
				
				// Compute error
				this.errorRed   = pixel[x][y].getRed()   - newPixel.getRed();
				this.errorGreen = pixel[x][y].getGreen() - newPixel.getGreen();
				this.errorBlue  = pixel[x][y].getBlue()  - newPixel.getBlue();
				
				// Spread error among neighbors
				pixel[x+1][y]   = getErrorPixel(pixel[x+1][y],   7f);
				pixel[x-1][y+1] = getErrorPixel(pixel[x-1][y+1], 3f);
				pixel[x][y+1]   = getErrorPixel(pixel[x][y+1],   5f);
				pixel[x+1][y+1] = getErrorPixel(pixel[x+1][y+1], 1f);
			}
		}
		
		for(int x = 0; x < this.width; x++)
			for(int y = 0; y < this.height; y++)
				this.ditheredImage.setRGB(x, y, pixel[x][y].hashCode());
	}
	
	private Color findClosestPalleteColor(Color color) {
		Color bestOption = palleteColors[0];
		for(int i = 1; i < palleteColors.length; i++)
			if (getDistance(bestOption, color) > getDistance(palleteColors[i], color))
				bestOption = palleteColors[i];
		return bestOption;
	}
	
	private int getDistance(Color a, Color b) {
		return (int) (Math.pow(a.getRed() - b.getRed(), 2) +
				Math.pow(a.getGreen() - b.getGreen(), 2) +
						Math.pow(a.getBlue() - b.getBlue(), 2));
	}
	
	private Color getErrorPixel(Color pixel, float factor) {
		float red = pixel.getRed() + factor / 16 * this.errorRed;
		float green = pixel.getGreen() + factor / 16 * this.errorGreen;
		float blue = pixel.getBlue() + factor / 16 * this.errorBlue;
		return new Color(normalize(red), normalize(green), normalize(blue));
	}
	
	private int normalize(float x) {
		if (x < 0)
			return 0;
		else if (x > 255)
			return 255;
		else
			return (int)x;
	}
}