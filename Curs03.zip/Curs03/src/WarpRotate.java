import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class WarpRotate extends JPanel {

	private BufferedImage initialImage, processedImage;
	private int width, height;
	double degree;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String filename = "ciri.jpg";
		double degree = 60;
		WarpRotate mainFrame = new WarpRotate(filename, degree);
		mainFrame.displayResult();
	}

	public void displayResult() {
		JFrame frame = new JFrame();

		ImageIcon icon1 = new ImageIcon(initialImage);
		ImageIcon icon2 = new ImageIcon(processedImage);

		JLabel label1 = new JLabel(icon1); 
		JLabel label2 = new JLabel(icon2); 

		add(label1);
		add(label2);

		frame.add(this);
		frame.pack();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	public WarpRotate(String filename, double degree) throws IOException {

		this.initialImage = ImageIO.read(new File(filename));
		width = initialImage.getWidth();
		height = initialImage.getHeight();
		
		this.processedImage = new BufferedImage(this.width, this.height, BufferedImage.TYPE_INT_RGB);
		
		this.degree = degree;

		algorithm();
	}

	private void algorithm() {
		Color pixel[][] = new Color[this.width][this.height];
		for(int x = 0; x < this.width; x++)
			for(int y = 0; y < this.height; y++)
				pixel[x][y] = new Color(this.initialImage.getRGB(x, y));
		
		double angle = Math.toRadians(degree);
        double sin = Math.sin(angle);
        double cos = Math.cos(angle);
        double x0 = 0.5 * (width  - 1); 
        double y0 = 0.5 * (height - 1);

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                double a = x - x0;
                double b = y - y0;
                int xx = (int) (+a * cos - b * sin + x0);
                int yy = (int) (+a * sin + b * cos + y0);

                if (xx >= 0 && xx < width && yy >= 0 && yy < height) {
                    this.processedImage.setRGB(x, y, pixel[xx][yy].hashCode());
                }
            }
        }

	}
}