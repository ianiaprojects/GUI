/*
public class AntialiasingBlurring {

	private static int width = 500;
	private static int height = 500;
	private static int thikness = 50;
	
	BufferedImage image;
	Color[][] pixelColor = new Color[width][height];
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new AntialiasingBlurring();
	}

	public AntialiasingBlurring() {
		displayFrame();
	}
	
	private void displayFrame() {
		JFrame frame = new JFrame();
		ImageIcon icon = new ImageIcon(image);
		JLabel label = new JLabel(icon);
		frame.add(label);
		frame.pack();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
*/

import static java.lang.Math.abs;
import static java.lang.Math.floor;
import static java.lang.Math.round;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
 
@SuppressWarnings("unused")
public class AntialiasingBlurring extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private BufferedImage image;
	private int width, height, xA, yA, xB, yB;
	Graphics2D g;
	private static int thickness = 5;
	
	public static void main(String[] args) {
		int width = 210, height = 210;
		AntialiasingBlurring mainFrame = new AntialiasingBlurring(width, height, 0, 200, 200, 0);
		mainFrame.displayResult();
    }
	
	public void displayResult() {
		JFrame frame = new JFrame();

		frame.add(this);
		frame.pack();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
    public AntialiasingBlurring(int width, int height, int xA, int yA, int xB, int yB) {
    	this.width = width;
    	this.height = height;
    	this.xA = xA; this.yA = yA;
    	this.xB = xB; this.yB = yB;
        setPreferredSize(new Dimension(width, height));
        setBackground(Color.white);
    }
 
    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        g = (Graphics2D) graphics;
        drawLine(this.xA, this.yA, this.xB, this.yB);
    }
    
    // Xiaolin Wu's line algorithm is implemented to draw the line
    void drawLine(double x0, double y0, double x1, double y1) {
 
        boolean steep = abs(y1 - y0) > abs(x1 - x0);
        if (steep)
            drawLine(y0, x0, y1, x1);
 
        if (x0 > x1)
            drawLine(x1, y1, x0, y0);
 
        double gradient = (x1 - x0)/(y1 - y0);
 
        double xEnd = round(x0);
        double yEnd = y0 + gradient * (xEnd - x0);
        double xGap = decimalComplement(x0 + 0.5);
        double xPxl1 = xEnd;
        double yPxl1 = (int)(yEnd);
 
        if (steep) {
            plot(yPxl1, xPxl1, decimalComplement(yEnd) * xGap);
            plot(yPxl1 + 1, xPxl1, decimalPart(yEnd) * xGap);
        } else {
            plot(xPxl1, yPxl1, decimalComplement(yEnd) * xGap);
            plot(xPxl1, yPxl1 + 1, decimalPart(yEnd) * xGap);
        }
 
        double intery = yEnd + gradient;
 
        xEnd = round(x1);
        yEnd = y1 + gradient * (xEnd - x1);
        xGap = decimalPart(x1 + 0.5);
        double xPxl2 = xEnd;
        double yPxl2 = (int)yEnd;
 
        if (steep) {
            plot(yPxl2, xPxl2, decimalComplement(yEnd) * xGap);
            plot(yPxl2 + 1, xPxl2, decimalPart(yEnd) * xGap);
        } else {
            plot(xPxl2, yPxl2, decimalComplement(yEnd) * xGap);
            plot(xPxl2, yPxl2 + 1, decimalPart(yEnd) * xGap);
        }
 
        for (double x = xPxl1 + 1; x <= xPxl2 - 1; x++) {
            if (steep) {
                plot((int)intery, x, decimalComplement(intery));
                plot((int)intery + 1, x, decimalPart(intery));
            } else {
                plot(x, (int)intery, decimalComplement(intery));
                plot(x, (int)intery + 1, decimalPart(intery));
            }
            intery = intery + gradient;
        }
    }
 
    void plot(double x, double y, double c) {
        g.setColor(new Color(0, 0, 0, (float)c));
        g.fillRect((int) x, (int) y, thickness, thickness);
    }
 
    double decimalPart(double x) {
        return x - Math.floor(x);
    }
 
    double decimalComplement(double x) {
        return 1.0 - decimalPart(x);
    }
}