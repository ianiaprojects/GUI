import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class BasicBlending extends JPanel {

	private BufferedImage firstImage, secondImage, mergedImage;
	private int width, height;
	private static double blendFactor = 0.5; 
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String filename1 = "blend1.jpg";
		String filename2 = "blend2.jpg";
		
		BasicBlending blend = new BasicBlending(filename1, filename2);
		blend.displayResult();
	}
	
	public BasicBlending(String filename1, String filename2) throws IOException {
		this.firstImage = ImageIO.read(new File(filename1));
		this.secondImage = ImageIO.read(new File(filename2));
		
		if(firstImage.getWidth() < secondImage.getWidth())
			this.width = firstImage.getWidth();
		else
			this.width = secondImage.getWidth();

		if(firstImage.getHeight() < secondImage.getHeight())
			this.height = firstImage.getHeight();
		else
			this.height = secondImage.getHeight();
		
		blend();
	}
	
	public void displayResult() {
		JFrame frame = new JFrame();

		//ImageIcon icon1 = new ImageIcon(this.firstImage);
		//ImageIcon icon2 = new ImageIcon(this.secondImage);
		ImageIcon icon3 = new ImageIcon(this.mergedImage);

		//JLabel label1 = new JLabel(icon1); 
		//JLabel label2 = new JLabel(icon2); 
		JLabel label3 = new JLabel(icon3);

		//add(label1);
		//add(label2);
		add(label3);

		frame.add(this);
		frame.pack();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	private void blend() {
		// TODO Auto-generated method stub
		mergedImage = new BufferedImage(this.width, this.height, BufferedImage.TYPE_INT_RGB);
		
		for(int x = 0; x < this.width; x++) {
			for(int y = 0; y < this.height; y++) {
				Color img1Pixel = new Color(this.firstImage.getRGB(x, y));
				Color img2Pixel = new Color(this.secondImage.getRGB(x, y));
				
				int img1Red = img1Pixel.getRed();
				int img1Green = img1Pixel.getGreen();
				int img1Blue = img1Pixel.getBlue();
				
				int img2Red = img2Pixel.getRed();
				int img2Green = img2Pixel.getGreen();
				int img2Blue = img2Pixel.getBlue();
				
				int mergeRed = (int) (img1Red * blendFactor + img2Red * (1 - blendFactor));
				int mergeGreen = (int) (img1Green * blendFactor + img2Green * (1 - blendFactor));
				int mergeBlue = (int) (img1Blue * blendFactor + img2Blue * (1 - blendFactor));
				
				mergeRed = normalize(mergeRed);
				mergeGreen = normalize(mergeGreen);
				mergeBlue = normalize(mergeBlue);
				
				Color c = new Color(mergeRed, mergeGreen, mergeBlue);
				this.mergedImage.setRGB(x, y, c.hashCode());
			}
		}
	}

	private int normalize(float x) {
		if (x < 0)
			return 0;
		else if (x > 255)
			return 255;
		else
			return (int)x;
	}
}
