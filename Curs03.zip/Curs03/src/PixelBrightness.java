import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PixelBrightness extends JPanel {

	private BufferedImage initialImage, contrastImage;
	private int width, height;
	private static double k = 1.5;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String filename = "ciri.jpg";
		PixelBrightness mainFrame = new PixelBrightness(filename);
		mainFrame.displayResult();
	}

	public void displayResult() {
		JFrame frame = new JFrame();

		ImageIcon icon1 = new ImageIcon(initialImage);
		ImageIcon icon2 = new ImageIcon(contrastImage);

		JLabel label1 = new JLabel(icon1); 
		JLabel label2 = new JLabel(icon2); 

		add(label1);
		add(label2);

		frame.add(this);
		frame.pack();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	public PixelBrightness(String filename) throws IOException {

		this.initialImage = ImageIO.read(new File(filename));
		this.contrastImage = ImageIO.read(new File(filename));

		width = initialImage.getWidth();
		height = initialImage.getHeight();

		algorithm();
	}

	private void algorithm() {
		Color pixel[][] = new Color[this.width][this.height];
		for(int x = 0; x < this.width; x++)
			for(int y = 0; y < this.height; y++)
				pixel[x][y] = new Color(this.initialImage.getRGB(x, y));

		for (int x = 0; x < this.width; x++) {
			for(int y = 0; y < this.height; y++) {			
				Color c = new Color(this.initialImage.getRGB(x, y));
				int red   = (int) (k * c.getRed());
				int green = (int) (k * c.getGreen());
				int blue  = (int) (k  * c.getBlue());

				red = normalize(red);
				green = normalize(green);
				blue = normalize(blue);
				this.contrastImage.setRGB(x, y, new Color(red, green, blue).getRGB());
			}
		}

	}
	
	private int normalize(float x) {
		if (x < 0)
			return 0;
		else if (x > 255)
			return 255;
		else
			return (int)x;
	}
}