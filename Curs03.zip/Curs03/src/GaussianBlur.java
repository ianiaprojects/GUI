import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class GaussianBlur extends JPanel {

	private BufferedImage originalImage, processedImage;
	private int width, height;
	private static int kernelLength = 9;
	private static double factor  = 4;
	private double[] kernel;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String filename1 = "ciri.jpg";

		GaussianBlur blur = new GaussianBlur(filename1);
		blur.displayResult();
	}

	public GaussianBlur(String filename) throws IOException {
		this.originalImage = ImageIO.read(new File(filename));
		this.processedImage = ImageIO.read(new File(filename));

		this.width = this.originalImage.getWidth();
		this.height = this.originalImage.getHeight();

		computeKernel();
		blur();
	}

	public void displayResult() {
		JFrame frame = new JFrame();

		ImageIcon icon1 = new ImageIcon(this.originalImage);
		ImageIcon icon2 = new ImageIcon(this.processedImage);

		JLabel label1 = new JLabel(icon1); 
		JLabel label2 = new JLabel(icon2);

		add(label1);
		add(label2);

		frame.add(this);
		frame.pack();

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

	private void computeKernel() {
		kernel = new double[kernelLength * kernelLength];
		for (int i = 0; i < kernelLength; i++) {
			double x = i - (kernelLength - 1) / 2;

			for (int j = 0; j < kernelLength; j++) {
				double y = j - (kernelLength - 1) / 2;

				kernel[j + i * kernelLength] = 1 / (2 * Math.PI * Math.pow(factor, 2)) * Math.exp( - ( Math.pow(x, 2) +  Math.pow(y, 2)) / (2 *  Math.pow(factor, 2)));
			}
		}

		double kernelSum = 0.0;
		for (int i = 0; i < kernelLength; i++) {
			for (int j = 0; j < kernelLength; j++) {
				kernelSum = kernelSum + kernel[j + i * kernelLength];
			}
		}

		for (int i = 0; i < kernelLength; i++) {
			for (int j = 0; j < kernelLength; j++) {
				kernel[j + i * kernelLength] = kernel[j + i * kernelLength] / kernelSum;
			}
		}
	}

	private void blur() {
		for (int x = 0; x < width; x++) {
			for(int y = 0; y < this.height; y++) {	

				double overflow = 0;
				int counter = 0, halfKernelLength = (kernelLength - 1) / 2;

				double r = 0, g = 0, b = 0;
				for (int i = x - halfKernelLength; i < x + halfKernelLength; i++) {
					for (int j = y - halfKernelLength; j < y + halfKernelLength; j++) {

						if (i < 0 || i >= this.width || j < 0 || j >= this.height) {	
							overflow = overflow + kernel[++counter];
							continue;
						}

						Color c = new Color(this.originalImage.getRGB(i, j));
						r = r + c.getRed()   * kernel[counter];
						g = g + c.getGreen() * kernel[counter];
						b = b + c.getBlue()  * kernel[counter];
						counter++;
					}
					counter++;
				}

				if (overflow > 0) {
					// reset
					counter = 0;
					r = 0; g = 0; b = 0;
					for (int i = x - halfKernelLength; i < x + halfKernelLength; i++) {
						for (int j = y - halfKernelLength; j < y + halfKernelLength; j++) {

							if (i < 0 || i >= this.width || j < 0 || j >= this.height) {
								counter++;
								continue;
							}

							Color c = new Color(this.originalImage.getRGB(i, j));
							r = r + c.getRed()   * kernel[counter] * (1 / (1 - overflow));
							g = g + c.getGreen() * kernel[counter] * (1 / (1 - overflow));
							b = b + c.getBlue()  * kernel[counter] * (1 / (1 - overflow));
							counter++;
						}
						counter++;
					}
				}
				r = normalize(r);
				g = normalize(g);
				b = normalize(b);
				this.processedImage.setRGB(x, y, new Color((int) r, (int) g, (int) b).getRGB());
			}
		}
	}

	private int normalize(double red) {
		if (red < 0)
			return 0;
		else if (red > 255)
			return 255;
		else
			return (int)red;
	}
}
